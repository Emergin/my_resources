import pygame
import sys
from game_constants import *
from game_objects import *

# Initialize pygame
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Sokoban')

def main():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        draw_game(screen, MAP)
        pygame.display.flip()

if __name__ == "__main__":
    main()

