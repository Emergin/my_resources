import pygame
from game_constants import *

def draw_game(screen, MAP):
    screen.fill(WHITE)
    for y, row in enumerate(MAP):
        for x, char in enumerate(row):
            if char == WALL:
                pygame.draw.rect(screen, BLUE, (x*TILE_SIZE, y*TILE_SIZE, TILE_SIZE, TILE_SIZE))
            elif char == PLAYER:
                pygame.draw.circle(screen, RED, (x*TILE_SIZE + TILE_SIZE//2, y*TILE_SIZE + TILE_SIZE//2), TILE_SIZE//2 - 5)
            elif char == BOX:
                pygame.draw.rect(screen, GREEN, (x*TILE_SIZE + 5, y*TILE_SIZE + 5, TILE_SIZE - 10, TILE_SIZE - 10))
            elif char == TARGET:
                pygame.draw.circle(screen, BLACK, (x*TILE_SIZE + TILE_SIZE//2, y*TILE_SIZE + TILE_SIZE//2), 5)

